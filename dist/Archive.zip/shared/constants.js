"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paramMissingError = void 0;
exports.paramMissingError = 'One or more of the required parameters was missing.';
